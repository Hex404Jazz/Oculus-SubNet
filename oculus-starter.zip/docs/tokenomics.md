# Tokenomics

$OCU supply, stablecoin reserves.