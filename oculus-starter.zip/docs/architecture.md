# Oculus Architecture

Explains subnet, contracts, wallet, SDK, and API.