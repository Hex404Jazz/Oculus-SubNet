import { ethers } from "ethers";

export class OculusSDK {
  provider: ethers.JsonRpcProvider;

  constructor(rpcUrl: string) {
    this.provider = new ethers.JsonRpcProvider(rpcUrl);
  }

  async getBalance(address: string, tokenAddress: string) {
    const erc20 = new ethers.Contract(
      tokenAddress,
      ["function balanceOf(address owner) view returns (uint256)"],
      this.provider
    );
    return await erc20.balanceOf(address);
  }
}
