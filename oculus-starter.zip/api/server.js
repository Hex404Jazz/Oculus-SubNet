import express from "express";
import bodyParser from "body-parser";

const app = express();
app.use(bodyParser.json());

app.get("/health", (req, res) => {
  res.json({ status: "ok", service: "Oculus API" });
});

app.listen(4000, () => console.log("🚀 Oculus API running on port 4000"));
